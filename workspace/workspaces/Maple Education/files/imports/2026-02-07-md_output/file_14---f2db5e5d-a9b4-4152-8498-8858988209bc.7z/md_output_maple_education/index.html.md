---
title: "index.html"
source_path: "index.html"
tags: ["Maple", "html"]
ocr: false
---

# index.html

简介：内容概述：<!doctype html>

## 内容

```text
<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8" />
  <meta http-equiv="refresh" content="0; url=School_Matchboard.html" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Maple Education Matchboard</title>
</head>
<body>
  <p>If you are not redirected, <a href="School_Matchboard.html">open the matchboard</a>.</p>
</body>
</html>
```
