---
title: "Template_04_返佣项目清单_sample.xlsx"
source_path: "01_Legal_and_Contracts/Templates/Template_04_返佣项目清单_sample.xlsx"
tags: ["合同", "返佣", "清单", "说明", "新加坡", "xlsx"]
ocr: false
---

# Template_04_返佣项目清单_sample.xlsx

简介：返佣/佣金清单，列出项目、比例与奖励规则。

## 内容

```text
[Sheet: 返佣清单]
国家/地区,院校名称,项目/专业,学段/学制,入读年份/季节,基准佣金（币种/金额）,分期与支付节点,扣费说明,备注
新加坡,示例大学A,本科-商业管理,本科3年,2025年秋季,SGD 1500/学生,注册后一次性支付,外方汇款扣费以实际到账为准,按上游更新
```
