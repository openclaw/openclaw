import JSON5 from 'json5';
import type { OpenClawConfig, SecureClawConfig } from './types.js';

type UnknownRecord = Record<string, unknown>;

function isRecord(value: unknown): value is UnknownRecord {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function extractNestedSecureClawConfig(raw: UnknownRecord): SecureClawConfig | undefined {
  const plugins = raw['plugins'];
  if (!isRecord(plugins)) return undefined;

  const entries = plugins['entries'];
  if (!isRecord(entries)) return undefined;

  const secureclawEntry = entries['secureclaw'];
  if (!isRecord(secureclawEntry)) return undefined;

  const pluginConfig = secureclawEntry['config'];
  if (!isRecord(pluginConfig)) return undefined;

  return pluginConfig as SecureClawConfig;
}

export function normalizeOpenClawConfig(
  rawConfig: unknown,
  pluginConfig?: unknown,
): OpenClawConfig {
  const base = isRecord(rawConfig) ? ({ ...rawConfig } as OpenClawConfig) : {};
  const topLevelSecureClaw = isRecord(base.secureclaw) ? base.secureclaw : undefined;
  const nestedSecureClaw = isRecord(rawConfig) ? extractNestedSecureClawConfig(rawConfig) : undefined;
  const runtimePluginConfig = isRecord(pluginConfig) ? (pluginConfig as SecureClawConfig) : undefined;

  const mergedSecureClaw: SecureClawConfig = {
    ...(topLevelSecureClaw ?? {}),
    ...(nestedSecureClaw ?? {}),
    ...(runtimePluginConfig ?? {}),
  };

  if (Object.keys(mergedSecureClaw).length > 0) {
    base.secureclaw = mergedSecureClaw;
  }

  return base;
}

export function parseOpenClawConfig(
  configContent: string,
  pluginConfig?: unknown,
): OpenClawConfig {
  return normalizeOpenClawConfig(parseOpenClawConfigDocument(configContent), pluginConfig);
}

export function parseOpenClawConfigDocument(configContent: string): OpenClawConfig {
  const parsed = JSON5.parse(configContent);
  return isRecord(parsed) ? (parsed as OpenClawConfig) : {};
}
