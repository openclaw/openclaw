import { describe, it, expect } from 'vitest';
import * as fs from 'node:fs/promises';
import * as path from 'node:path';
import { fileURLToPath } from 'node:url';

const projectRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const scriptsDir = path.join(projectRoot, 'skill', 'scripts');

async function readScript(name: string): Promise<string> {
  return fs.readFile(path.join(scriptsDir, name), 'utf-8');
}

describe('SecureClaw shell scripts', () => {
  it('install and maintenance scripts share the common path helper', async () => {
    const scriptNames = [
      'install.sh',
      'quick-audit.sh',
      'quick-harden.sh',
      'check-integrity.sh',
      'scan-skills.sh',
      'uninstall.sh',
      'emergency-response.sh',
    ];

    for (const scriptName of scriptNames) {
      const content = await readScript(scriptName);
      expect(content).toContain('lib.sh');
    }
  });

  it('quick-harden prefers loopback and OpenClaw CLI config writes', async () => {
    const content = await readScript('quick-harden.sh');

    expect(content).toContain('"loopback"');
    expect(content).toContain('openclaw config set gateway.bind loopback');
    expect(content).not.toContain('"127.0.0.1"');
    expect(content).not.toContain('json.load(');
  });

  it('scan-skills scans both managed and workspace skill roots by default', async () => {
    const content = await readScript('scan-skills.sh');

    expect(content).toContain('sc_print_skill_roots');
    expect(content).toContain('workspace');
  });

  it('audit and integrity scripts inspect workspace cognitive files', async () => {
    const audit = await readScript('quick-audit.sh');
    const integrity = await readScript('check-integrity.sh');
    const emergency = await readScript('emergency-response.sh');

    expect(audit).toContain('WORKSPACE_DIR');
    expect(integrity).toContain('WORKSPACE_DIR');
    expect(emergency).toContain('WORKSPACE_DIR');
  });
});
