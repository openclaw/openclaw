#!/bin/bash
# SecureClaw Skill Supply Chain Scanner
# Developed by Adversa AI - Agentic AI Security and Red Teaming Pioneers
# https://adversa.ai
# Usage: bash scan-skills.sh
#        bash scan-skills.sh /path/to/skill
set -euo pipefail

SCRIPT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
# shellcheck source=lib.sh
. "$SCRIPT_ROOT/scripts/lib.sh"

OPENCLAW_DIR="$(sc_resolve_state_dir || true)"
[ -z "$OPENCLAW_DIR" ] && echo "No OpenClaw found" && exit 1
CONFIG_PATH="$(sc_resolve_config_path "$OPENCLAW_DIR")"
WORKSPACE_DIR="$(sc_resolve_workspace_dir "$OPENCLAW_DIR" "$CONFIG_PATH")"

TARGET_PATH="${1:-}"

echo "SecureClaw Skill Supply Chain Scan"
echo "========================================"
echo "State dir: $OPENCLAW_DIR"
echo "Workspace: $WORKSPACE_DIR"

SAFE=0
SUS=0
T=0
SKIPPED=0

scan_dir() {
  local d="$1"
  local n="$2"
  local issues=""

  T=$((T + 1))

  grep -rl 'curl.*|.*sh\|wget.*|.*bash\|curl.*|.*python' "$d" 2>/dev/null | head -1 | grep -q . \
    && issues="${issues}  CRIT Remote code execution\n" || true

  grep -rl 'eval(\|exec(\|Function(\|subprocess\.\|os\.system' "$d" 2>/dev/null | head -1 | grep -q . \
    && issues="${issues}  CRIT Dynamic code execution\n" || true

  grep -rl 'atob(\|btoa(\|String\.fromCharCode\|\\x[0-9a-f]' "$d" 2>/dev/null | head -1 | grep -q . \
    && issues="${issues}  HIGH Obfuscated code\n" || true

  grep -rl 'process\.env\|\.env\|api_key\|apiKey' "$d" 2>/dev/null | grep -v node_modules | head -1 | grep -q . \
    && issues="${issues}  HIGH Credential access\n" || true

  grep -rl 'SOUL\.md\|IDENTITY\.md\|TOOLS\.md\|openclaw\.json' "$d" 2>/dev/null | head -1 | grep -q . \
    && issues="${issues}  HIGH Config/identity modification\n" || true

  grep -rl 'osascript.*display\|xattr.*quarantine\|ClickFix\|webhook\.site' "$d" 2>/dev/null | head -1 | grep -q . \
    && issues="${issues}  CRIT ClawHavoc campaign pattern\n" || true

  case "$n" in
    *solana-wallet*|*phantom-tracker*|*polymarket-*|*better-polymarket*|*auto-updater*|*clawhub[0-9]*|*clawhubb*|*cllawhub*)
      issues="${issues}  CRIT Name matches ClawHavoc blocklist\n"
      ;;
  esac

  if [ -z "$issues" ]; then
    echo "PASS $n - clean"
    SAFE=$((SAFE + 1))
  else
    echo "WARN $n:"
    printf '%b' "$issues"
    SUS=$((SUS + 1))
  fi
}

if [ -n "$TARGET_PATH" ]; then
  if [ ! -d "$TARGET_PATH" ]; then
    echo "Nothing to scan at $TARGET_PATH"
    exit 0
  fi

  scan_dir "$TARGET_PATH" "$(basename "$TARGET_PATH")"
else
  ROOTS=()
  while IFS= read -r root; do
    [ -n "$root" ] && ROOTS+=("$root")
  done < <(sc_print_skill_roots "$OPENCLAW_DIR" "$WORKSPACE_DIR")

  if [ ${#ROOTS[@]} -eq 0 ]; then
    echo "Nothing to scan in managed or workspace skill roots"
    exit 0
  fi

  for root in "${ROOTS[@]}"; do
    echo ""
    echo "Scanning root: $root"
    for skill_dir in "$root"/*/; do
      [ -d "$skill_dir" ] || continue
      [ "$(basename "$skill_dir")" = "secureclaw" ] && SKIPPED=$((SKIPPED + 1)) && continue
      scan_dir "$skill_dir" "$(basename "$skill_dir")"
    done
  done
fi

echo ""
echo "Scanned $T target(s): $SAFE clean, $SUS suspicious"
if [ $SKIPPED -gt 0 ]; then
  echo "Skipped $SKIPPED SecureClaw copy/copies"
fi
if [ $SUS -gt 0 ]; then
  echo "Review suspicious skills and remove anything you did not install yourself."
fi
