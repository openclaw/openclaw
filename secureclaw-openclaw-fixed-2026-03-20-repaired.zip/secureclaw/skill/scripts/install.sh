#!/bin/bash
# SecureClaw Installer & Updater
# Developed by Adversa AI - Agentic AI Security and Red Teaming Pioneers
# https://adversa.ai
set -euo pipefail

SCRIPT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
# shellcheck source=lib.sh
. "$SCRIPT_ROOT/scripts/lib.sh"

echo "SecureClaw Installer"
echo "=================================="

OPENCLAW_DIR="$(sc_resolve_state_dir || true)"
[ -z "$OPENCLAW_DIR" ] && echo "No OpenClaw installation found" && exit 1
CONFIG_PATH="$(sc_resolve_config_path "$OPENCLAW_DIR")"
WORKSPACE_DIR="$(sc_resolve_workspace_dir "$OPENCLAW_DIR" "$CONFIG_PATH")"

echo "State dir: $OPENCLAW_DIR"
echo "Workspace: $WORKSPACE_DIR"

MANAGED_DEST="$OPENCLAW_DIR/skills/secureclaw"
WORKSPACE_SKILLS="$WORKSPACE_DIR/skills/secureclaw"

NEW_VER="unknown"
if [ -f "$SCRIPT_ROOT/skill.json" ]; then
  NEW_VER=$(grep '"version"' "$SCRIPT_ROOT/skill.json" | head -1 | sed 's/.*"version".*"\([^"]*\)".*/\1/')
fi

copy_skill_tree() {
  local destination="$1"
  local label="$2"

  if [ "$(cd "$SCRIPT_ROOT" && pwd -P)" = "$(cd "$destination" 2>/dev/null && pwd -P)" ] 2>/dev/null; then
    echo "$label source and destination are the same - skipping copy"
    return 0
  fi

  mkdir -p "$destination"
  cp -r "$SCRIPT_ROOT"/* "$destination/"
  chmod +x "$destination/scripts/"*.sh
  echo "Installed to $label: $destination"
}

if [ -d "$MANAGED_DEST" ]; then
  OLD_VER="unknown"
  if [ -f "$MANAGED_DEST/skill.json" ]; then
    OLD_VER=$(grep '"version"' "$MANAGED_DEST/skill.json" | head -1 | sed 's/.*"version".*"\([^"]*\)".*/\1/')
  fi

  if [ "$OLD_VER" = "$NEW_VER" ]; then
    echo "Already at v$NEW_VER - reinstalling"
  else
    echo "Updating: v$OLD_VER -> v$NEW_VER"
  fi

  BACKUP_DIR="$MANAGED_DEST.bak.$(date +%s)"
  echo "Backing up managed skill to $(basename "$BACKUP_DIR")"
  cp -r "$MANAGED_DEST" "$BACKUP_DIR"
else
  echo "Fresh install - v$NEW_VER"
fi

if [ -d "$OPENCLAW_DIR/skills/secureclaw-advisor" ]; then
  rm -rf "$OPENCLAW_DIR/skills/secureclaw-advisor"
  echo "Removed old secureclaw-advisor from managed skills"
fi

if [ -d "$WORKSPACE_DIR/skills/secureclaw-advisor" ]; then
  rm -rf "$WORKSPACE_DIR/skills/secureclaw-advisor"
  echo "Removed old secureclaw-advisor from workspace skills"
fi

copy_skill_tree "$MANAGED_DEST" "managed skill root"
copy_skill_tree "$WORKSPACE_SKILLS" "workspace skill root"

TOOLS_FILE="$WORKSPACE_DIR/TOOLS.md"
if [ -f "$TOOLS_FILE" ] && ! grep -q "## SecureClaw Security Skill" "$TOOLS_FILE" 2>/dev/null; then
  cat >> "$TOOLS_FILE" << 'TOOLS_EOF'

---

## SecureClaw Security Skill (v2.2.0)

Security hardening skill by Adversa AI. 15 core rules, 9 scripts, 4 pattern databases.

### Rules

Read and follow all 15 rules in `skills/secureclaw/SKILL.md` at all times.

### Scripts

All scripts are in `skills/secureclaw/scripts/`. Run with bash:

```
bash skills/secureclaw/scripts/quick-audit.sh
bash skills/secureclaw/scripts/quick-harden.sh
bash skills/secureclaw/scripts/check-integrity.sh
bash skills/secureclaw/scripts/check-privacy.sh
bash skills/secureclaw/scripts/scan-skills.sh
bash skills/secureclaw/scripts/check-advisories.sh
bash skills/secureclaw/scripts/emergency-response.sh
```
TOOLS_EOF
  echo "Registered SecureClaw in workspace TOOLS.md"
fi

AGENTS_FILE="$WORKSPACE_DIR/AGENTS.md"
if [ -f "$AGENTS_FILE" ] && ! grep -q "SecureClaw Security Skill" "$AGENTS_FILE" 2>/dev/null; then
  cat >> "$AGENTS_FILE" << 'AGENTS_EOF'

### SecureClaw Security Skill (v2.2.0) - ALWAYS ACTIVE

Your workspace has the SecureClaw security skill installed. Follow the 15 core security rules in `skills/secureclaw/SKILL.md` at all times.

SecureClaw protects against: prompt injection, credential exposure, supply chain threats, memory tampering, cost overruns, file integrity violations, and inter-agent attacks.

**Run audits:** `bash skills/secureclaw/scripts/quick-audit.sh`

**Apply hardening:** `bash skills/secureclaw/scripts/quick-harden.sh`

See `TOOLS.md` for the complete SecureClaw reference and available scripts.
AGENTS_EOF
  echo "Registered SecureClaw in workspace AGENTS.md"
fi

echo ""
echo "SecureClaw v$NEW_VER installed"
echo "Managed skill root:   $MANAGED_DEST"
echo "Workspace skill root: $WORKSPACE_SKILLS"
echo ""
echo "Next steps:"
echo "  1. Run audit:  bash $MANAGED_DEST/scripts/quick-audit.sh"
echo "  2. Fix issues: bash $MANAGED_DEST/scripts/quick-harden.sh"
echo "  3. Restart OpenClaw so the workspace skill is rediscovered"
