#!/bin/bash
# Shared helpers for SecureClaw shell scripts.

sc_expand_home_path() {
  local input="${1:-}"

  case "$input" in
    "~")
      printf '%s\n' "$HOME"
      ;;
    "~/"*)
      printf '%s/%s\n' "$HOME" "${input#~/}"
      ;;
    *)
      printf '%s\n' "$input"
      ;;
  esac
}

sc_unique_lines() {
  awk '!seen[$0]++'
}

sc_resolve_state_dir() {
  local candidates=()
  local candidate=""

  if [ -n "${OPENCLAW_STATE_DIR:-}" ]; then
    candidates+=("$(sc_expand_home_path "$OPENCLAW_STATE_DIR")")
  fi

  candidates+=(
    "$HOME/.openclaw"
    "$HOME/.moltbot"
    "$HOME/.clawdbot"
    "$HOME/clawd"
  )

  for candidate in "${candidates[@]}"; do
    [ -d "$candidate" ] && printf '%s\n' "$candidate" && return 0
  done

  if [ -n "${OPENCLAW_STATE_DIR:-}" ]; then
    printf '%s\n' "$(sc_expand_home_path "$OPENCLAW_STATE_DIR")"
    return 0
  fi

  return 1
}

sc_resolve_config_path() {
  local state_dir="$1"
  local explicit_config=""
  local candidate=""

  if [ -n "${OPENCLAW_CONFIG_PATH:-}" ]; then
    explicit_config="$(sc_expand_home_path "$OPENCLAW_CONFIG_PATH")"
    printf '%s\n' "$explicit_config"
    return 0
  fi

  for candidate in \
    "$state_dir/openclaw.json" \
    "$state_dir/moltbot.json" \
    "$state_dir/clawdbot.json"
  do
    [ -f "$candidate" ] && printf '%s\n' "$candidate" && return 0
  done

  printf '%s\n' "$state_dir/openclaw.json"
}

sc_extract_workspace_from_config() {
  local config_path="$1"
  local workspace=""

  [ -f "$config_path" ] || return 1

  workspace="$(
    grep -E '^[[:space:]]*["'\''"]?workspace["'\''"]?[[:space:]]*:' "$config_path" 2>/dev/null \
      | head -1 \
      | sed -E 's/.*:[[:space:]]*["'\''"]?([^,"'\''}]+).*/\1/'
  )"

  [ -n "$workspace" ] || return 1
  sc_expand_home_path "$workspace"
}

sc_dir_has_workspace_markers() {
  local dir="$1"

  [ -d "$dir" ] || return 1
  [ -f "$dir/AGENTS.md" ] && return 0
  [ -f "$dir/SOUL.md" ] && return 0
  [ -f "$dir/TOOLS.md" ] && return 0
  [ -d "$dir/skills" ] && return 0
  return 1
}

sc_resolve_workspace_dir() {
  local state_dir="$1"
  local config_path="${2:-}"
  local configured_workspace=""
  local default_workspace="$state_dir/workspace"

  if [ -n "${OPENCLAW_WORKSPACE_DIR:-}" ]; then
    printf '%s\n' "$(sc_expand_home_path "$OPENCLAW_WORKSPACE_DIR")"
    return 0
  fi

  if configured_workspace="$(sc_extract_workspace_from_config "$config_path" 2>/dev/null)"; then
    printf '%s\n' "$configured_workspace"
    return 0
  fi

  if sc_dir_has_workspace_markers "$default_workspace"; then
    printf '%s\n' "$default_workspace"
    return 0
  fi

  printf '%s\n' "$default_workspace"
}

sc_resolve_agent_dir() {
  local state_dir="$1"

  if [ -n "${OPENCLAW_AGENT_DIR:-}" ]; then
    printf '%s\n' "$(sc_expand_home_path "$OPENCLAW_AGENT_DIR")"
    return 0
  fi

  if [ -n "${PI_CODING_AGENT_DIR:-}" ]; then
    printf '%s\n' "$(sc_expand_home_path "$PI_CODING_AGENT_DIR")"
    return 0
  fi

  printf '%s\n' "$state_dir/agents"
}

sc_print_bootstrap_roots() {
  local state_dir="$1"
  local workspace_dir="$2"

  printf '%s\n' "$state_dir"
  printf '%s\n' "$workspace_dir"
}

sc_print_skill_roots() {
  local state_dir="$1"
  local workspace_dir="$2"

  {
    [ -d "$state_dir/skills" ] && printf '%s\n' "$state_dir/skills"
    [ -d "$workspace_dir/skills" ] && printf '%s\n' "$workspace_dir/skills"
  } | sc_unique_lines
}

sc_sha256_file() {
  local target="$1"

  if command -v sha256sum >/dev/null 2>&1; then
    sha256sum "$target" | awk '{print $1}'
    return 0
  fi

  if command -v shasum >/dev/null 2>&1; then
    shasum -a 256 "$target" | awk '{print $1}'
    return 0
  fi

  if command -v openssl >/dev/null 2>&1; then
    openssl dgst -sha256 -r "$target" | awk '{print $1}'
    return 0
  fi

  return 1
}
