#!/bin/bash
# SecureClaw Security Audit v2.2
# Covers: OWASP ASI + MITRE ATLAS + CSA MAESTRO + NIST AI 100-2
# Developed by Adversa AI - Agentic AI Security and Red Teaming Pioneers
# https://adversa.ai
set -euo pipefail

SCRIPT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
# shellcheck source=lib.sh
. "$SCRIPT_ROOT/scripts/lib.sh"

OPENCLAW_DIR="$(sc_resolve_state_dir || true)"
[ -z "$OPENCLAW_DIR" ] && echo "No OpenClaw installation found" && exit 1
CONFIG_PATH="$(sc_resolve_config_path "$OPENCLAW_DIR")"
WORKSPACE_DIR="$(sc_resolve_workspace_dir "$OPENCLAW_DIR" "$CONFIG_PATH")"
AGENT_DIR="$(sc_resolve_agent_dir "$OPENCLAW_DIR")"

echo "SecureClaw Security Audit"
echo "============================"
echo "State dir: $OPENCLAW_DIR"
echo "Workspace: $WORKSPACE_DIR"
echo "Config: $CONFIG_PATH"
echo ""

C=0
H=0
M=0
P=0

chk() {
  local sev="$1" area="$2" name="$3" result="$4" msg="${5:-}"

  if [ "$result" = "FAIL" ]; then
    case "$sev" in
      C) printf 'CRIT  [%s] %s -> %s\n' "$area" "$name" "$msg"; C=$((C + 1)) ;;
      H) printf 'HIGH  [%s] %s -> %s\n' "$area" "$name" "$msg"; H=$((H + 1)) ;;
      M) printf 'MED   [%s] %s -> %s\n' "$area" "$name" "$msg"; M=$((M + 1)) ;;
    esac
  else
    printf 'PASS  [%s] %s\n' "$area" "$name"
    P=$((P + 1))
  fi
}

get_perms() {
  local p
  p=$(stat -c '%a' "$1" 2>/dev/null) && [ ${#p} -le 4 ] && echo "$p" && return
  p=$(stat -f '%Lp' "$1" 2>/dev/null) && [ ${#p} -le 4 ] && echo "$p" && return
  echo "?"
}

OPENCLAW_VERSION=""
if command -v openclaw >/dev/null 2>&1; then
  OPENCLAW_VERSION="$(
    openclaw --version 2>/dev/null \
      | grep -oE '[0-9]{4}\.[0-9]+\.[0-9]+(-[0-9]+)?' \
      | head -1 || true
  )"
elif [ -f "$OPENCLAW_DIR/package.json" ]; then
  OPENCLAW_VERSION="$(
    grep '"version"' "$OPENCLAW_DIR/package.json" 2>/dev/null \
      | head -1 \
      | grep -oE '[0-9]{4}\.[0-9]+\.[0-9]+(-[0-9]+)?' || true
  )"
fi

if [ -n "$OPENCLAW_VERSION" ]; then
  if echo "$OPENCLAW_VERSION" | grep -qE '^2025\.|^2026\.0\.|^2026\.1\.[0-9]$|^2026\.1\.1[0-9]$|^2026\.1\.2[0-8]$'; then
    chk C "ASI05|L4|evasion" "OpenClaw version (CVE-2026-25253)" FAIL "v$OPENCLAW_VERSION vulnerable to 1-click RCE - update now"
  else
    chk C "ASI05|L4" "OpenClaw version" PASS
  fi
fi

if [ -f "$CONFIG_PATH" ]; then
  if grep -Eq "[\"']bind[\"'][[:space:]]*:[[:space:]]*[\"'](lan|0\\.0\\.0\\.0)[\"']" "$CONFIG_PATH" 2>/dev/null; then
    chk C "ASI03|L4|evasion" "Gateway bind" FAIL "Non-loopback gateway bind detected"
  else
    chk C "ASI03|L4" "Gateway bind" PASS
  fi

  if grep -q '"authToken"' "$CONFIG_PATH" 2>/dev/null; then
    chk C "ASI03|L4" "Gateway authentication" PASS
  elif grep -q '"auth"' "$CONFIG_PATH" 2>/dev/null && grep -q '"mode"' "$CONFIG_PATH" 2>/dev/null && grep -q '"token"' "$CONFIG_PATH" 2>/dev/null; then
    chk C "ASI03|L4" "Gateway authentication" PASS
  else
    chk C "ASI03|L4|evasion" "Gateway authentication" FAIL "No auth token configured"
  fi
else
  chk C "ASI03|L4|evasion" "Gateway config" FAIL "No config file found"
fi

if [ -f "$OPENCLAW_DIR/.env" ]; then
  PERMS=$(get_perms "$OPENCLAW_DIR/.env")
  if [ "$PERMS" = "600" ] || [ "$PERMS" = "400" ]; then
    chk H "ASI03|L4" ".env permissions" PASS
  else
    chk H "ASI03|L4|privacy" ".env permissions" FAIL "Permissions $PERMS (need 600)"
  fi
fi

DP=$(get_perms "$OPENCLAW_DIR")
if [ "$DP" = "700" ] || [ "$DP" = "750" ]; then
  chk H "ASI03|L4" "Directory permissions" PASS
else
  chk H "ASI03|L4|privacy" "Directory permissions" FAIL "Permissions $DP (need 700)"
fi

LEAKED=$(
  grep -rl 'sk-ant-\|sk-proj-\|xoxb-\|xoxp-\|ghp_\|gho_\|AKIA' "$OPENCLAW_DIR" 2>/dev/null \
    | grep -v '.env' \
    | grep -v 'node_modules' \
    | grep -v '.secureclaw/' \
    | grep -v 'skills/secureclaw/' \
    | head -5 || true
)
if [ -z "$LEAKED" ]; then
  chk H "ASI03|L4" "Plaintext key exposure" PASS
else
  chk H "ASI03|L4|privacy" "Plaintext key exposure" FAIL "Keys outside .env: $LEAKED"
fi

if [ -f "$CONFIG_PATH" ]; then
  if grep -q '"exec"' "$CONFIG_PATH" 2>/dev/null && grep -q '"host".*"sandbox"' "$CONFIG_PATH" 2>/dev/null; then
    chk H "ASI05|L3" "Sandbox mode" PASS
  else
    chk H "ASI05|L3|misuse" "Sandbox mode" FAIL "tools.exec.host not set to sandbox"
  fi

  if grep -q '"approvals".*"always"' "$CONFIG_PATH" 2>/dev/null; then
    chk H "ASI02|L3" "Exec approval mode" PASS
  else
    chk H "ASI02|L3|misuse" "Exec approval mode" FAIL "exec.approvals not set to always"
  fi
fi

RELAY=$(lsof -i :18790 2>/dev/null || ss -tlnp 2>/dev/null | grep 18790 || true)
if [ -z "$RELAY" ]; then
  chk H "ASI05|L4" "Browser relay" PASS
else
  chk H "ASI05|L4|evasion" "Browser relay" FAIL "Active on :18790"
fi

ROOT_ISSUES=""
while IFS= read -r skill_root; do
  [ -n "$skill_root" ] || continue
  SUS=$(
    grep -rl 'curl.*|.*sh\|wget.*|.*bash\|eval(\|osascript.*display\|webhook\.site' "$skill_root" 2>/dev/null \
      | grep -v 'skills/secureclaw/' \
      | head -5 || true
  )
  [ -n "$SUS" ] && ROOT_ISSUES="${ROOT_ISSUES}${SUS}"$'\n'
done < <(sc_print_skill_roots "$OPENCLAW_DIR" "$WORKSPACE_DIR")

if [ -z "$ROOT_ISSUES" ]; then
  chk M "ASI04|L7" "Skill safety scan" PASS
else
  chk M "ASI04|L7|poisoning" "Skill safety scan" FAIL "$(printf '%s' "$ROOT_ISSUES" | head -5 | tr '\n' ' ')"
fi

for f in SOUL.md IDENTITY.md TOOLS.md AGENTS.md SECURITY.md MEMORY.md; do
  if [ -f "$WORKSPACE_DIR/$f" ]; then
    MOD=$(find "$WORKSPACE_DIR/$f" -mmin -60 -print 2>/dev/null || true)
    if [ -z "$MOD" ]; then
      chk M "ASI06|L2" "$f integrity" PASS
    else
      chk M "ASI06|L2|poisoning" "$f integrity" FAIL "Modified in last hour - verify intentional"
    fi
  fi
done

if ls "$OPENCLAW_DIR/.secureclaw/baselines"/workspace__*.sha256 >/dev/null 2>&1; then
  chk M "ASI06|L2" "Workspace cognitive file baselines" PASS
else
  chk M "ASI06|L2|poisoning" "Workspace cognitive file baselines" FAIL "No workspace baselines - run quick-harden.sh"
fi

if [ -f "$CONFIG_PATH" ]; then
  if grep -q '"dmPolicy".*"pairing"' "$CONFIG_PATH" 2>/dev/null; then
    chk H "ASI07|L7" "DM policy" PASS
  else
    chk H "ASI07|L7|evasion" "DM policy" FAIL "Open to unsolicited agent messages"
  fi
fi

if [ -f "$WORKSPACE_DIR/SOUL.md" ]; then
  if grep -qi 'never.*name\|privacy\|stranger test\|secureclaw' "$WORKSPACE_DIR/SOUL.md" 2>/dev/null; then
    chk H "ASI09|L2" "Privacy directives" PASS
  else
    chk H "ASI09|L2|privacy" "Privacy directives" FAIL "No privacy rules in workspace SOUL.md"
  fi
fi

if [ -f "$CONFIG_PATH" ]; then
  if grep -qi '"costLimit"\|"budget"\|"maxTokens"' "$CONFIG_PATH" 2>/dev/null; then
    chk M "ASI08|L5" "Cost/budget limits" PASS
  else
    chk M "ASI08|L5|misuse" "Cost/budget limits" FAIL "No cost limits configured"
  fi
fi

if command -v openclaw >/dev/null 2>&1 && openclaw secureclaw audit --help >/dev/null 2>&1; then
  chk M "ASI10|L5" "SecureClaw plugin (kill switch)" PASS
else
  chk M "ASI10|L5|misuse" "SecureClaw plugin (kill switch)" FAIL "Not installed"
fi

if [ -f "$OPENCLAW_DIR/.secureclaw/killswitch" ]; then
  echo ""
  echo "KILL SWITCH ACTIVE - all agent operations should be suspended"
  echo "Remove: rm $OPENCLAW_DIR/.secureclaw/killswitch"
  echo ""
fi

for mf in SOUL.md IDENTITY.md TOOLS.md AGENTS.md MEMORY.md; do
  if [ -f "$WORKSPACE_DIR/$mf" ]; then
    if grep -qiE '(ignore previous|new instructions|system prompt override|you are now|disregard|forget your rules)' "$WORKSPACE_DIR/$mf" 2>/dev/null; then
      chk C "ATLAS|L2|poisoning" "$mf memory trust" FAIL "Possible injected instructions detected"
    else
      chk M "ATLAS|L2" "$mf memory trust" PASS
    fi
  fi
done

if [ -d "$AGENT_DIR" ]; then
  for dir in "$AGENT_DIR"/*/; do
    [ -d "$dir" ] || continue
    agent_name="$(basename "$dir")"
    for mf in soul.md SOUL.md MEMORY.md; do
      if [ -f "$dir/$mf" ] && grep -qiE '(ignore previous|new instructions|system prompt override|you are now|disregard|forget your rules)' "$dir/$mf" 2>/dev/null; then
        chk C "ATLAS|L2|poisoning" "$agent_name/$mf memory trust" FAIL "Possible injected instructions"
      fi
    done
  done
fi

if [ -f "$CONFIG_PATH" ]; then
  if grep -q '"controlTokens"' "$CONFIG_PATH" 2>/dev/null; then
    chk M "ATLAS|L3" "Control token customization" PASS
  else
    chk M "ATLAS|L3|evasion" "Control token customization" FAIL "Default control tokens in use"
  fi

  if grep -q '"failureMode"' "$CONFIG_PATH" 2>/dev/null; then
    chk M "CoSAI|L5" "Failure mode configured" PASS
  else
    chk M "CoSAI|L5" "Failure mode configured" FAIL "No failureMode set"
  fi
fi

echo ""
T=$((C + H + M + P))
S=0
[ $T -gt 0 ] && S=$(( (P * 100) / T ))
echo "Security Score: $S/100"
echo "  $P passed  $C critical  $H high  $M medium"
echo ""
[ $C -gt 0 ] && echo "Fix critical issues now: bash $(dirname "$0")/quick-harden.sh"
[ $C -eq 0 ] && [ $H -gt 0 ] && echo "Fix high issues soon: bash $(dirname "$0")/quick-harden.sh"
echo "Full runtime protection: openclaw plugins install secureclaw"

if [ $C -gt 0 ]; then
  exit 2
fi
