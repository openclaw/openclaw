#!/bin/bash
# SecureClaw Emergency Response
# Developed by Adversa AI - Agentic AI Security and Red Teaming Pioneers
# https://adversa.ai
set -euo pipefail

SCRIPT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
# shellcheck source=lib.sh
. "$SCRIPT_ROOT/scripts/lib.sh"

OPENCLAW_DIR="$(sc_resolve_state_dir || true)"
[ -z "$OPENCLAW_DIR" ] && echo "No OpenClaw found" && exit 1
CONFIG_PATH="$(sc_resolve_config_path "$OPENCLAW_DIR")"
WORKSPACE_DIR="$(sc_resolve_workspace_dir "$OPENCLAW_DIR" "$CONFIG_PATH")"
AGENT_DIR="$(sc_resolve_agent_dir "$OPENCLAW_DIR")"

echo "SecureClaw EMERGENCY RESPONSE"
echo "================================="
echo "Time: $(date -u +%Y-%m-%dT%H:%M:%SZ)"
echo "Workspace: $WORKSPACE_DIR"
echo "Agent dir: $AGENT_DIR"
echo ""

if command -v openclaw >/dev/null 2>&1 && openclaw secureclaw status --help >/dev/null 2>&1; then
  echo "Plugin detected - running plugin audit..."
  openclaw secureclaw audit
  exit 0
fi

echo "No plugin - running manual emergency checks"
echo ""

echo "Checking cognitive file integrity"
bash "$SCRIPT_ROOT/scripts/check-integrity.sh" 2>/dev/null || echo "Integrity check failed or baselines missing"
echo ""

echo "Files modified in last 30 minutes"
find "$WORKSPACE_DIR" -maxdepth 2 -mmin -30 -type f 2>/dev/null | grep -v node_modules | grep -v '.git' || echo "  None found"
if [ -d "$AGENT_DIR" ]; then
  find "$AGENT_DIR" -maxdepth 3 -mmin -30 -type f 2>/dev/null | grep -v sessions || true
fi
echo ""

echo "Open ports check"
if command -v lsof >/dev/null 2>&1; then
  lsof -i -P -n 2>/dev/null | grep -i 'openclaw\|moltbot\|clawdbot\|node.*LISTEN\|18789\|18790' || echo "  No OpenClaw ports detected"
elif command -v ss >/dev/null 2>&1; then
  ss -tlnp 2>/dev/null | grep -E '18789|18790' || echo "  No OpenClaw ports detected"
fi
echo ""

echo "Suspicious processes"
ps aux 2>/dev/null | grep -iE 'curl.*\|.*sh|wget.*\|.*bash|nc -|ncat ' | grep -v grep || echo "  None found"
echo ""

echo "Quick security audit"
bash "$SCRIPT_ROOT/scripts/quick-audit.sh" 2>/dev/null || echo "Audit failed"
echo ""

if mkdir -p "$OPENCLAW_DIR/.secureclaw" 2>/dev/null; then
  echo "[$(date -u +%Y-%m-%dT%H:%M:%SZ)] EMERGENCY_RESPONSE triggered" >> "$OPENCLAW_DIR/.secureclaw/events.log" 2>/dev/null \
    || echo "Could not write to incident log"
else
  echo "Could not create log directory"
fi

echo ""
echo "RECOMMENDED ACTIONS FOR YOUR HUMAN:"
echo ""
echo "  1. Stop the OpenClaw gateway process"
echo "  2. Review $WORKSPACE_DIR/SOUL.md and $WORKSPACE_DIR/MEMORY.md for unauthorized changes"
echo "  3. Review $AGENT_DIR/*/MEMORY.md for suspicious prompt injection or context poisoning"
echo "  4. Check session logs and config history for unusual activity"
echo "  5. Rotate all API keys and credentials"
echo "  6. Review managed and workspace skills for unfamiliar entries"
echo ""
echo "For automated incident response, install the full plugin:"
echo "  npx openclaw plugins install secureclaw"
echo "  npx openclaw secureclaw audit"
