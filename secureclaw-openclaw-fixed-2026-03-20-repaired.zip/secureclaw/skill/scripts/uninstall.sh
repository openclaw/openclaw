#!/bin/bash
# SecureClaw Uninstaller
# Developed by Adversa AI - Agentic AI Security and Red Teaming Pioneers
# https://adversa.ai
set -euo pipefail

SCRIPT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
# shellcheck source=lib.sh
. "$SCRIPT_ROOT/scripts/lib.sh"

echo "SecureClaw Uninstaller"
echo "============================"

OPENCLAW_DIR="$(sc_resolve_state_dir || true)"
[ -z "$OPENCLAW_DIR" ] && echo "No OpenClaw installation found" && exit 1
CONFIG_PATH="$(sc_resolve_config_path "$OPENCLAW_DIR")"
WORKSPACE_DIR="$(sc_resolve_workspace_dir "$OPENCLAW_DIR" "$CONFIG_PATH")"

MANAGED_DEST="$OPENCLAW_DIR/skills/secureclaw"
WORKSPACE_DEST="$WORKSPACE_DIR/skills/secureclaw"

if [ ! -d "$MANAGED_DEST" ] && [ ! -d "$WORKSPACE_DEST" ]; then
  echo "SecureClaw skill not installed in managed or workspace roots"
  exit 0
fi

VER="unknown"
if [ -f "$MANAGED_DEST/skill.json" ]; then
  VER=$(grep '"version"' "$MANAGED_DEST/skill.json" | head -1 | sed 's/.*"version".*"\([^"]*\)".*/\1/')
elif [ -f "$WORKSPACE_DEST/skill.json" ]; then
  VER=$(grep '"version"' "$WORKSPACE_DEST/skill.json" | head -1 | sed 's/.*"version".*"\([^"]*\)".*/\1/')
fi

echo "Found SecureClaw v$VER"
echo "Managed root:   $MANAGED_DEST"
echo "Workspace root: $WORKSPACE_DEST"

FORCE="${1:-}"
if [ "$FORCE" != "--force" ]; then
  echo ""
  echo "This will remove:"
  [ -d "$MANAGED_DEST" ] && echo "  - $MANAGED_DEST/"
  [ -d "$WORKSPACE_DEST" ] && echo "  - $WORKSPACE_DEST/"
  echo "  - $OPENCLAW_DIR/.secureclaw/baselines/"
  echo ""
  echo "This will NOT remove:"
  echo "  - SecureClaw directives added to workspace cognitive files"
  echo "  - Backup directories (*.bak.*)"
  echo "  - The SecureClaw plugin if it was installed with openclaw plugins"
  echo ""
  echo "Run with --force to proceed: bash $0 --force"
  exit 0
fi

for target in "$MANAGED_DEST" "$WORKSPACE_DEST"; do
  if [ -d "$target" ]; then
    echo "Removing $target/"
    rm -rf "$target"
  fi
done

if [ -d "$OPENCLAW_DIR/.secureclaw/baselines" ]; then
  echo "Removing integrity baselines"
  rm -rf "$OPENCLAW_DIR/.secureclaw/baselines"
fi

if [ -d "$OPENCLAW_DIR/.secureclaw" ]; then
  rmdir "$OPENCLAW_DIR/.secureclaw" 2>/dev/null || true
fi

for backup_glob in "$MANAGED_DEST".bak.* "$WORKSPACE_DEST".bak.*; do
  for backup_dir in $backup_glob; do
    [ -d "$backup_dir" ] || continue
    echo "Removing backup $backup_dir"
    rm -rf "$backup_dir"
  done
done

echo ""
echo "SecureClaw skill removed"
echo ""
echo "Manual steps:"
echo "  1. Review $WORKSPACE_DIR/SOUL.md and remove SecureClaw sections if desired"
echo "  2. Review $WORKSPACE_DIR/AGENTS.md and $WORKSPACE_DIR/TOOLS.md for SecureClaw notes"
echo "  3. Restart your agent so workspace skill discovery refreshes"
