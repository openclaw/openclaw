#!/bin/bash
# SecureClaw Cognitive File Integrity Check
# Developed by Adversa AI - Agentic AI Security and Red Teaming Pioneers
# https://adversa.ai
set -euo pipefail

SCRIPT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
# shellcheck source=lib.sh
. "$SCRIPT_ROOT/scripts/lib.sh"

OPENCLAW_DIR="$(sc_resolve_state_dir || true)"
[ -z "$OPENCLAW_DIR" ] && echo "No OpenClaw found" && exit 1
CONFIG_PATH="$(sc_resolve_config_path "$OPENCLAW_DIR")"
WORKSPACE_DIR="$(sc_resolve_workspace_dir "$OPENCLAW_DIR" "$CONFIG_PATH")"
AGENT_DIR="$(sc_resolve_agent_dir "$OPENCLAW_DIR")"
BASELINE_DIR="$OPENCLAW_DIR/.secureclaw/baselines"
REBASELINE="${1:-}"

workspace_targets() {
  local f
  for f in SOUL.md IDENTITY.md TOOLS.md AGENTS.md SECURITY.md MEMORY.md; do
    [ -f "$WORKSPACE_DIR/$f" ] && printf 'workspace__%s|%s\n' "$f" "$WORKSPACE_DIR/$f"
  done
}

agent_targets() {
  local dir=""
  local agent_name=""
  local f=""
  [ -d "$AGENT_DIR" ] || return 0

  for dir in "$AGENT_DIR"/*/; do
    [ -d "$dir" ] || continue
    agent_name="$(basename "$dir")"
    for f in SOUL.md soul.md MEMORY.md; do
      [ -f "$dir/$f" ] && printf 'agents__%s__%s|%s\n' "$agent_name" "$f" "$dir/$f"
    done
  done
}

write_baselines() {
  local created=0
  local key=""
  local file_path=""

  mkdir -p "$BASELINE_DIR"
  while IFS='|' read -r key file_path; do
    [ -n "$key" ] || continue
    if sc_sha256_file "$file_path" > "$BASELINE_DIR/$key.sha256"; then
      created=$((created + 1))
    else
      rm -f "$BASELINE_DIR/$key.sha256"
      echo "Failed to hash $file_path - skipping"
    fi
  done < <(
    {
      workspace_targets
      agent_targets
    }
  )

  if [ $created -eq 0 ]; then
    echo "No workspace or agent cognitive files found to baseline."
  else
    echo "Baselines created for $created file(s). Run again without --rebaseline to check."
  fi
}

if [ ! -d "$BASELINE_DIR" ] || [ "$REBASELINE" = "--rebaseline" ]; then
  echo "Creating baselines..."
  write_baselines
  exit 0
fi

echo "SecureClaw Cognitive File Integrity"
echo "========================================="
echo "Workspace: $WORKSPACE_DIR"
echo "Agent dir: $AGENT_DIR"
TAMPERED=0
MISSING=0
CHECKED=0

while IFS='|' read -r key file_path; do
  [ -n "$key" ] || continue

  if [ -f "$BASELINE_DIR/$key.sha256" ] && [ -f "$file_path" ]; then
    EXPECTED="$(awk '{print $1}' "$BASELINE_DIR/$key.sha256")"
    CURRENT="$(sc_sha256_file "$file_path" || true)"
    CHECKED=$((CHECKED + 1))
    if [ -n "$CURRENT" ] && [ "$EXPECTED" = "$CURRENT" ]; then
      echo "PASS ${key#workspace__} - intact"
    else
      echo "ALERT ${key#workspace__} - TAMPERED (hash mismatch)"
      echo "  Expected: ${EXPECTED:0:16}..."
      echo "  Current:  ${CURRENT:0:16}..."
      TAMPERED=$((TAMPERED + 1))
    fi
  elif [ ! -f "$BASELINE_DIR/$key.sha256" ] && [ -f "$file_path" ]; then
    echo "WARN ${key#workspace__} - no baseline (run with --rebaseline)"
  elif [ -f "$BASELINE_DIR/$key.sha256" ] && [ ! -f "$file_path" ]; then
    echo "ALERT ${key#workspace__} - DELETED (baseline exists but file is missing)"
    MISSING=$((MISSING + 1))
  fi
done < <(
  {
    workspace_targets
    agent_targets
  }
)

ISSUES=$((TAMPERED + MISSING))
if [ $ISSUES -gt 0 ]; then
  echo ""
  echo "$ISSUES file(s) tampered or missing. Review changes immediately."
  [ $TAMPERED -gt 0 ] && echo "  $TAMPERED file(s) modified since last baseline."
  [ $MISSING -gt 0 ] && echo "  $MISSING file(s) deleted since last baseline."
  echo "  If changes were intentional: bash $0 --rebaseline"
  echo "  If NOT intentional: you may be compromised - run emergency-response.sh"
  exit 2
elif [ $CHECKED -eq 0 ]; then
  echo "No cognitive files found to check."
else
  echo ""
  echo "All $CHECKED cognitive file(s) intact"
fi
